#include <iostream>
#include <fstream>
using namespace std;
int *growarray(int *a, int &size)
{
    int *temp;
    temp = new int[size + 1];
    for (int i = 0; i < size; i++)
    {
        temp[i] = a[i];
    }
    delete[] a;
    a = nullptr;
    size++;
    return temp;
}

void multiply(int r, int c, int r1, int c1, int **&a, int **b, int **w, int **w1, int *q, int *q1)
{
    int **temp;
    temp = new int *[r];
    for (int i = 0; i < r; i++)
    {
        for (int j = 0; j < c; j++)
        {
            if (q[i] == q1[i])
                a[i][j] *= b[i][j];
        }
    }
}
void add(int r, int c, int r1, int c1, int **&a, int **b, int **w, int **w1, int *q, int *q1)
{
    for (int i = 0; i < r; i++)
    {
        for (int j = 0; j < c; j++)
        {
            a[i][j]+=b[i][j];
        }
    }
}
void transpose(int &r, int &c, int **a, int **w, int *q)
{
    int **temp;
    temp = new int *[c];
    for (int i = 0; i < c; i++)
    {
        *(temp + i) = new int[r];
        temp[i][r] = 0;
    }
    for (int i = 0; i < 2; i++)
        ;
}
void output(int r, int c, int **a, int **w, int *q)
{
    for (int i = 0; i < r; i++)
    {
        for (int j = 0, k = 0; j < c; j++)
        {
            if (j == w[i][k])
            {
                if (a[i][k] < 9)
                {
                    cout << a[i][k] << "    ";
                    k++;
                }
                else if (a[i][k] > 9 && a[i][k] < 100)
                {
                    cout << a[i][k] << "   ";
                    k++;
                }
                else if (a[i][k] > 99 && a[i][k] < 1000)
                {
                    cout << a[i][k] << "  ";
                    k++;
                }
                else if (a[i][k] > 999 && a[i][k] < 10000)
                {
                    cout << a[i][k] << " ";
                    k++;
                }
            }
            else
                cout << "0" << "    ";
        }
        cout << endl;
    }
}

void input(int &r, int &c, int **&a, int **&w, int *&q)
{
    int test, test2, test3;
    ifstream fin("input.txt");
    fin >> r >> c;
    a = new int *[r];

    q = new int[r];
    w = new int *[r];
    for (int i = 0; i < r; i++)
    {
        fin >> q[i];
        *(a + i) = new int[q[i]];
        *(w + i) = new int[q[i]];
        for (int j = 0; j < q[i]; j++)
        {
            fin >> w[i][j];
            fin >> a[i][j];
        }
    }
    for (int i = 0; i < r; i++)
    {
        for (int j = 0; j < q[i]; j++)
        {
            cout << w[i][j];
        }
        cout << endl;
    }
}

int main()
{
    ifstream fin("input.txt");
    int r, r1, c, c1;
    int **a;
    int **b;
    int *q;
    int **w;
    char opt;
    int *q1;
    int **w1;
    cout << "Enter the size of rows and columns respectively: " << endl;
    input(r, c, a, w, q);
    cout << "Your matrix is: " << endl;
    output(r, c, a, w, q);
    while (9696)
    {
        cout << "Select an option to perform a calculation!" << endl;
        cout << "Hit 1 to calculate transpose of the given matrix." << endl;
        cout << "Or hit 2 to add it to other matrix. " << endl;
        cout << "Or hit 3 to multiply it to another matrix: " << endl;
        cout << "Or hit 4 to close the program." << endl;
        cin >> opt;
        if (opt == '4')
        {
            cout << "Program closed successfully!";
            delete[] a;
            delete[] b;
            delete[] q;
            delete[] q1;
            delete[] w;
            delete[] w1;
            a = nullptr;
            b = nullptr;
            w = nullptr;
            w1 = nullptr;
            q = nullptr;
            q1 = nullptr;
            break;
        }
        if (opt == '1')
        {
            cout << "The transpose of the given matrix is: " << endl;
            transpose(r, c, a,w,q);
            output(r, c, a,w,q);
        }
        if (opt == '2')
        {
            cout << "Fetching data for the 2nd matrix from the file...." << endl;
            input(r1, c1, b, w1, q1);
            cout << "Your 2nd matrix is: " << endl;
            output(r1, c1, b, w1, q1);
            if (r1 != r || c1 != c)
            {
                cout << "The given matrices are incompatible for addition!" << endl;
            }
            else
            {
                add(r, c, r1,c1,a, b,w,w1,q,q1);
                cout << "The addition of the matrices is: " << endl;
                output(r, c, a, w, q);
            }
        }
        if (opt == '3')
        {
            cout << "Fetching data for the 2nd matrix from the file...." << endl;
            input(r1, c1, b, w1, q1);
            cout << "Your 2nd matrix is: " << endl;
            output(r1, c1, b, w1, q1);
            if (r != c1)
            {
                cout << "The given matrices are incompatible for multiplication!" << endl;
            }
            else
            {
                multiply(r, c, r1,c1,a, b,w,w1,q,q1);
                cout << "The multiplication of the matrices is: " << endl;
                output(r, c, a, w, q);
            }
        }
    }
}
